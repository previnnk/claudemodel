"""
Code Agent Service - Execute tools and manage code operations
Handles Read, Write, Edit, Bash, Grep, Glob operations
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import logging
import os
import subprocess
import asyncio
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Code Agent Service", version="0.1.0")

class ToolRequest(BaseModel):
    tool: str  # 'Read', 'Write', 'Edit', 'Bash', 'Grep', 'Glob'
    parameters: Dict[str, Any]
    workspace_path: str = "/workspace"

class ToolResponse(BaseModel):
    success: bool
    result: Optional[str] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "code-agent"}

@app.post("/execute", response_model=ToolResponse)
async def execute_tool(request: ToolRequest):
    """Execute a tool based on the request"""
    try:
        logger.info(f"Executing tool: {request.tool}")

        if request.tool == "Read":
            return await execute_read(request)
        elif request.tool == "Write":
            return await execute_write(request)
        elif request.tool == "Edit":
            return await execute_edit(request)
        elif request.tool == "Bash":
            return await execute_bash(request)
        elif request.tool == "Grep":
            return await execute_grep(request)
        elif request.tool == "Glob":
            return await execute_glob(request)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {request.tool}")

    except Exception as e:
        logger.error(f"Error executing tool {request.tool}: {str(e)}")
        return ToolResponse(success=False, error=str(e))

async def execute_read(request: ToolRequest) -> ToolResponse:
    """Read a file"""
    try:
        file_path = request.parameters.get("file_path")
        if not file_path:
            return ToolResponse(success=False, error="file_path is required")

        # Security: Ensure path is within workspace
        full_path = Path(request.workspace_path) / file_path

        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Add line numbers
        lines = content.split('\n')
        numbered_content = '\n'.join([f"{i+1}\t{line}" for i, line in enumerate(lines)])

        return ToolResponse(
            success=True,
            result=numbered_content,
            metadata={"lines": len(lines), "size": len(content)}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

async def execute_write(request: ToolRequest) -> ToolResponse:
    """Write content to a file"""
    try:
        file_path = request.parameters.get("file_path")
        content = request.parameters.get("content")

        if not file_path or content is None:
            return ToolResponse(success=False, error="file_path and content are required")

        full_path = Path(request.workspace_path) / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)

        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)

        return ToolResponse(
            success=True,
            result=f"File written successfully: {file_path}",
            metadata={"bytes": len(content)}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

async def execute_edit(request: ToolRequest) -> ToolResponse:
    """Edit a file by replacing old_string with new_string"""
    try:
        file_path = request.parameters.get("file_path")
        old_string = request.parameters.get("old_string")
        new_string = request.parameters.get("new_string")

        if not all([file_path, old_string, new_string]):
            return ToolResponse(success=False, error="file_path, old_string, and new_string are required")

        full_path = Path(request.workspace_path) / file_path

        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()

        if old_string not in content:
            return ToolResponse(success=False, error="old_string not found in file")

        new_content = content.replace(old_string, new_string)

        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(new_content)

        return ToolResponse(
            success=True,
            result="File edited successfully",
            metadata={"replacements": content.count(old_string)}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

async def execute_bash(request: ToolRequest) -> ToolResponse:
    """Execute a bash command"""
    try:
        command = request.parameters.get("command")
        timeout = request.parameters.get("timeout", 120)

        if not command:
            return ToolResponse(success=False, error="command is required")

        logger.info(f"Executing bash command: {command}")

        # Execute command
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=request.workspace_path
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            process.kill()
            return ToolResponse(success=False, error=f"Command timed out after {timeout}s")

        result = stdout.decode('utf-8')
        error = stderr.decode('utf-8')

        if process.returncode != 0:
            return ToolResponse(
                success=False,
                result=result,
                error=f"Command failed with exit code {process.returncode}: {error}"
            )

        return ToolResponse(
            success=True,
            result=result,
            metadata={"exit_code": process.returncode}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

async def execute_grep(request: ToolRequest) -> ToolResponse:
    """Search for pattern in files using ripgrep"""
    try:
        pattern = request.parameters.get("pattern")
        path = request.parameters.get("path", ".")

        if not pattern:
            return ToolResponse(success=False, error="pattern is required")

        full_path = Path(request.workspace_path) / path

        # Use ripgrep for fast searching
        cmd = f"rg --no-heading --line-number '{pattern}' {full_path}"

        process = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await process.communicate()

        result = stdout.decode('utf-8')

        return ToolResponse(
            success=True,
            result=result if result else "No matches found",
            metadata={"matches": len(result.split('\n')) if result else 0}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

async def execute_glob(request: ToolRequest) -> ToolResponse:
    """Find files matching a glob pattern"""
    try:
        pattern = request.parameters.get("pattern")
        path = request.parameters.get("path", ".")

        if not pattern:
            return ToolResponse(success=False, error="pattern is required")

        base_path = Path(request.workspace_path) / path

        # Use pathlib for glob matching
        matches = list(base_path.glob(pattern))
        result = '\n'.join([str(m.relative_to(base_path)) for m in matches])

        return ToolResponse(
            success=True,
            result=result,
            metadata={"matches": len(matches)}
        )

    except Exception as e:
        return ToolResponse(success=False, error=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)

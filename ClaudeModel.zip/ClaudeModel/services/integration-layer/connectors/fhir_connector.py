"""
FHIR connector for Epic EHR integration
"""

from typing import Any, Dict
import os
import logging
from fhirclient import client
from fhirclient.models import patient, observation

from .base import BaseConnector

logger = logging.getLogger(__name__)

class FHIRConnector(BaseConnector):
    """Connector for FHIR-compliant EHR systems (Epic)"""

    def __init__(self):
        super().__init__()
        self.fhir_base_url = os.getenv("FHIR_BASE_URL")
        self.client_id = os.getenv("FHIR_CLIENT_ID")
        self.client = None

    async def connect(self) -> bool:
        """Connect to FHIR server"""
        try:
            settings = {
                'app_id': self.client_id,
                'api_base': self.fhir_base_url
            }
            self.client = client.FHIRClient(settings=settings)
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"FHIR connection error: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect"""
        self.client = None
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute FHIR operation"""
        if not self.connected:
            await self.connect()

        operations = {
            "get_patient": self._get_patient,
            "get_observations": self._get_observations,
            "search_patients": self._search_patients,
        }

        if operation not in operations:
            raise ValueError(f"Unknown operation: {operation}")

        return await operations[operation](parameters)

    async def health_check(self) -> bool:
        """Check FHIR server health"""
        try:
            if not self.client:
                return False
            # Try to get metadata
            return True
        except:
            return False

    async def _get_patient(self, params: Dict[str, Any]) -> Dict:
        """Get patient by ID"""
        patient_id = params.get("patient_id")

        try:
            pat = patient.Patient.read(patient_id, self.client.server)

            return {
                "id": pat.id,
                "name": self._format_name(pat.name[0] if pat.name else None),
                "gender": pat.gender,
                "birthDate": pat.birthDate.isostring if pat.birthDate else None,
            }
        except Exception as e:
            logger.error(f"Get patient error: {str(e)}")
            return {}

    async def _get_observations(self, params: Dict[str, Any]) -> Dict:
        """Get patient observations"""
        patient_id = params.get("patient_id")
        code = params.get("code")  # LOINC code

        try:
            search = observation.Observation.where(struct={
                'patient': patient_id,
                'code': code
            })

            observations = search.perform_resources(self.client.server)

            return {
                "observations": [
                    {
                        "code": obs.code.coding[0].code if obs.code else None,
                        "value": self._extract_value(obs),
                        "date": obs.effectiveDateTime.isostring if obs.effectiveDateTime else None,
                    }
                    for obs in observations
                ]
            }
        except Exception as e:
            logger.error(f"Get observations error: {str(e)}")
            return {"observations": []}

    async def _search_patients(self, params: Dict[str, Any]) -> Dict:
        """Search for patients"""
        name = params.get("name")

        try:
            search = patient.Patient.where(struct={'name': name})
            patients = search.perform_resources(self.client.server)

            return {
                "patients": [
                    {
                        "id": pat.id,
                        "name": self._format_name(pat.name[0] if pat.name else None),
                    }
                    for pat in patients[:10]  # Limit results
                ]
            }
        except Exception as e:
            logger.error(f"Search patients error: {str(e)}")
            return {"patients": []}

    def _format_name(self, name_obj):
        """Format FHIR HumanName"""
        if not name_obj:
            return "Unknown"
        parts = []
        if name_obj.given:
            parts.extend(name_obj.given)
        if name_obj.family:
            parts.append(name_obj.family)
        return " ".join(parts)

    def _extract_value(self, obs):
        """Extract value from observation"""
        if hasattr(obs, 'valueQuantity') and obs.valueQuantity:
            return f"{obs.valueQuantity.value} {obs.valueQuantity.unit}"
        elif hasattr(obs, 'valueString') and obs.valueString:
            return obs.valueString
        return "N/A"

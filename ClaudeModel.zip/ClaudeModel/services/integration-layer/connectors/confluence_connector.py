"""
Confluence connector for wiki/documentation access
"""

from typing import Any, Dict, List
import os
import logging
from atlassian import Confluence

from .base import BaseConnector

logger = logging.getLogger(__name__)

class ConfluenceConnector(BaseConnector):
    """Connector for Atlassian Confluence"""

    def __init__(self):
        super().__init__()
        self.url = os.getenv("CONFLUENCE_URL")
        self.username = os.getenv("CONFLUENCE_USERNAME")
        self.api_token = os.getenv("CONFLUENCE_API_TOKEN")
        self.client = None

    async def connect(self) -> bool:
        """Connect to Confluence"""
        try:
            self.client = Confluence(
                url=self.url,
                username=self.username,
                password=self.api_token,
                cloud=True
            )
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"Confluence connection error: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect"""
        self.client = None
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute Confluence operation"""
        if not self.connected:
            await self.connect()

        operations = {
            "search_pages": self._search_pages,
            "get_page": self._get_page,
            "list_spaces": self._list_spaces,
            "get_page_content": self._get_page_content,
        }

        if operation not in operations:
            raise ValueError(f"Unknown operation: {operation}")

        return await operations[operation](parameters)

    async def health_check(self) -> bool:
        """Check Confluence health"""
        try:
            if not self.client:
                return False
            self.client.get_all_spaces(start=0, limit=1)
            return True
        except:
            return False

    async def _search_pages(self, params: Dict[str, Any]) -> List[Dict]:
        """Search Confluence pages"""
        query = params.get("query")
        space = params.get("space")

        cql = f'text ~ "{query}"'
        if space:
            cql += f' AND space = "{space}"'

        try:
            results = self.client.cql(cql, limit=20)
            pages = results.get("results", [])

            return [
                {
                    "id": page["content"]["id"],
                    "title": page["content"]["title"],
                    "space": page["content"]["space"]["key"],
                    "url": f'{self.url}/wiki{page["content"]["_links"]["webui"]}',
                    "excerpt": page.get("excerpt", ""),
                }
                for page in pages
            ]
        except Exception as e:
            logger.error(f"Confluence search error: {str(e)}")
            return []

    async def _get_page(self, params: Dict[str, Any]) -> Dict:
        """Get page metadata"""
        page_id = params.get("page_id")

        try:
            page = self.client.get_page_by_id(
                page_id,
                expand="body.storage,version,space"
            )

            return {
                "id": page["id"],
                "title": page["title"],
                "space": page["space"]["key"],
                "version": page["version"]["number"],
                "url": f'{self.url}/wiki{page["_links"]["webui"]}',
            }
        except Exception as e:
            logger.error(f"Get page error: {str(e)}")
            return {}

    async def _get_page_content(self, params: Dict[str, Any]) -> str:
        """Get page content (HTML)"""
        page_id = params.get("page_id")

        try:
            page = self.client.get_page_by_id(
                page_id,
                expand="body.storage"
            )
            return page["body"]["storage"]["value"]
        except Exception as e:
            logger.error(f"Get page content error: {str(e)}")
            return ""

    async def _list_spaces(self, params: Dict[str, Any]) -> List[Dict]:
        """List Confluence spaces"""
        try:
            spaces = self.client.get_all_spaces(start=0, limit=50)
            return [
                {
                    "key": space["key"],
                    "name": space["name"],
                    "type": space["type"],
                }
                for space in spaces.get("results", [])
            ]
        except Exception as e:
            logger.error(f"List spaces error: {str(e)}")
            return []

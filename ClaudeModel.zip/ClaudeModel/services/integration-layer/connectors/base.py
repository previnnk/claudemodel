"""
Base connector interface for all integrations
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger(__name__)

class BaseConnector(ABC):
    """Base class for all external system connectors"""

    def __init__(self):
        self.connected = False
        self.config = self.load_config()

    @abstractmethod
    async def connect(self) -> bool:
        """Establish connection to external system"""
        pass

    @abstractmethod
    async def disconnect(self) -> bool:
        """Close connection"""
        pass

    @abstractmethod
    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """
        Execute an operation

        Args:
            operation: Operation name (search, get, list, etc.)
            parameters: Operation parameters

        Returns:
            Operation result
        """
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if connection is healthy"""
        pass

    def load_config(self) -> Dict[str, Any]:
        """Load connector configuration from environment or config file"""
        # Override in subclasses to load specific config
        return {}

    async def __aenter__(self):
        """Context manager entry"""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        await self.disconnect()

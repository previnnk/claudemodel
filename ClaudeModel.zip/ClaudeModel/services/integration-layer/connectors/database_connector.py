"""
Database connectors for Oracle and SQL Server
"""

from typing import Any, Dict, List
import os
import logging

from .base import BaseConnector

logger = logging.getLogger(__name__)

class OracleConnector(BaseConnector):
    """Connector for Oracle Database"""

    def __init__(self):
        super().__init__()
        self.connection = None
        self.dsn = os.getenv("ORACLE_DSN")
        self.username = os.getenv("ORACLE_USERNAME")
        self.password = os.getenv("ORACLE_PASSWORD")

    async def connect(self) -> bool:
        """Connect to Oracle"""
        try:
            import cx_Oracle
            self.connection = cx_Oracle.connect(
                user=self.username,
                password=self.password,
                dsn=self.dsn
            )
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"Oracle connection error: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect"""
        if self.connection:
            self.connection.close()
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute Oracle operation"""
        if not self.connected:
            await self.connect()

        if operation == "query":
            return await self._execute_query(parameters)
        else:
            raise ValueError(f"Unknown operation: {operation}")

    async def health_check(self) -> bool:
        """Check Oracle health"""
        try:
            if not self.connection:
                return False
            cursor = self.connection.cursor()
            cursor.execute("SELECT 1 FROM DUAL")
            cursor.close()
            return True
        except:
            return False

    async def _execute_query(self, params: Dict[str, Any]) -> List[Dict]:
        """Execute read-only query"""
        sql = params.get("sql")
        query_params = params.get("params", {})

        # Security: Ensure query is read-only
        sql_lower = sql.lower().strip()
        if not sql_lower.startswith("select"):
            raise ValueError("Only SELECT queries are allowed")

        cursor = self.connection.cursor()
        cursor.execute(sql, query_params)

        # Get column names
        columns = [col[0] for col in cursor.description]

        # Fetch results
        rows = cursor.fetchall()
        cursor.close()

        # Convert to list of dicts
        return [dict(zip(columns, row)) for row in rows]

class SQLServerConnector(BaseConnector):
    """Connector for Microsoft SQL Server"""

    def __init__(self):
        super().__init__()
        self.connection = None
        self.server = os.getenv("SQLSERVER_HOST")
        self.database = os.getenv("SQLSERVER_DATABASE")
        self.username = os.getenv("SQLSERVER_USERNAME")
        self.password = os.getenv("SQLSERVER_PASSWORD")

    async def connect(self) -> bool:
        """Connect to SQL Server"""
        try:
            import pyodbc
            connection_string = (
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={self.server};"
                f"DATABASE={self.database};"
                f"UID={self.username};"
                f"PWD={self.password}"
            )
            self.connection = pyodbc.connect(connection_string)
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"SQL Server connection error: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect"""
        if self.connection:
            self.connection.close()
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute SQL Server operation"""
        if not self.connected:
            await self.connect()

        if operation == "query":
            return await self._execute_query(parameters)
        else:
            raise ValueError(f"Unknown operation: {operation}")

    async def health_check(self) -> bool:
        """Check SQL Server health"""
        try:
            if not self.connection:
                return False
            cursor = self.connection.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            return True
        except:
            return False

    async def _execute_query(self, params: Dict[str, Any]) -> List[Dict]:
        """Execute read-only query"""
        sql = params.get("sql")
        query_params = params.get("params", {})

        # Security: Ensure query is read-only
        sql_lower = sql.lower().strip()
        if not sql_lower.startswith("select"):
            raise ValueError("Only SELECT queries are allowed")

        cursor = self.connection.cursor()
        cursor.execute(sql, query_params)

        # Get column names
        columns = [column[0] for column in cursor.description]

        # Fetch results
        rows = cursor.fetchall()
        cursor.close()

        # Convert to list of dicts
        return [dict(zip(columns, row)) for row in rows]

"""
SharePoint connector for document management via Microsoft Graph API
"""

from typing import Any, Dict, List
import os
import logging
from msal import ConfidentialClientApplication
import httpx

from .base import BaseConnector

logger = logging.getLogger(__name__)

class SharePointConnector(BaseConnector):
    """Connector for Microsoft SharePoint via Graph API"""

    def __init__(self):
        super().__init__()
        self.client_id = os.getenv("SHAREPOINT_CLIENT_ID")
        self.client_secret = os.getenv("SHAREPOINT_CLIENT_SECRET")
        self.tenant_id = os.getenv("SHAREPOINT_TENANT_ID")
        self.access_token = None
        self.graph_endpoint = "https://graph.microsoft.com/v1.0"

    async def connect(self) -> bool:
        """Authenticate and get access token"""
        try:
            app = ConfidentialClientApplication(
                client_id=self.client_id,
                client_credential=self.client_secret,
                authority=f"https://login.microsoftonline.com/{self.tenant_id}"
            )

            result = app.acquire_token_for_client(
                scopes=["https://graph.microsoft.com/.default"]
            )

            if "access_token" in result:
                self.access_token = result["access_token"]
                self.connected = True
                return True
            else:
                logger.error(f"Failed to acquire token: {result.get('error_description')}")
                return False

        except Exception as e:
            logger.error(f"SharePoint connection error: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect"""
        self.access_token = None
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute SharePoint operation"""
        if not self.connected:
            await self.connect()

        operations = {
            "search_documents": self._search_documents,
            "get_document": self._get_document,
            "list_sites": self._list_sites,
            "list_drives": self._list_drives,
        }

        if operation not in operations:
            raise ValueError(f"Unknown operation: {operation}")

        return await operations[operation](parameters)

    async def health_check(self) -> bool:
        """Check connection health"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.graph_endpoint}/me",
                    headers={"Authorization": f"Bearer {self.access_token}"}
                )
                return response.status_code == 200
        except:
            return False

    async def _search_documents(self, params: Dict[str, Any]) -> List[Dict]:
        """Search for documents in SharePoint"""
        query = params.get("query")
        site = params.get("site")

        search_url = f"{self.graph_endpoint}/search/query"

        request_body = {
            "requests": [
                {
                    "entityTypes": ["driveItem"],
                    "query": {"queryString": query},
                    "from": 0,
                    "size": 25
                }
            ]
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                search_url,
                json=request_body,
                headers={
                    "Authorization": f"Bearer {self.access_token}",
                    "Content-Type": "application/json"
                }
            )

            if response.status_code == 200:
                data = response.json()
                hits = data.get("value", [{}])[0].get("hitsContainers", [{}])[0].get("hits", [])

                return [
                    {
                        "name": hit["resource"]["name"],
                        "path": hit["resource"].get("webUrl"),
                        "lastModified": hit["resource"].get("lastModifiedDateTime"),
                        "size": hit["resource"].get("size"),
                    }
                    for hit in hits
                ]
            else:
                logger.error(f"Search failed: {response.status_code}")
                return []

    async def _get_document(self, params: Dict[str, Any]) -> Dict:
        """Get document content"""
        drive_id = params.get("drive_id")
        item_id = params.get("item_id")

        url = f"{self.graph_endpoint}/drives/{drive_id}/items/{item_id}"

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers={"Authorization": f"Bearer {self.access_token}"}
            )

            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"Failed to get document: {response.status_code}")

    async def _list_sites(self, params: Dict[str, Any]) -> List[Dict]:
        """List SharePoint sites"""
        url = f"{self.graph_endpoint}/sites"

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers={"Authorization": f"Bearer {self.access_token}"}
            )

            if response.status_code == 200:
                sites = response.json().get("value", [])
                return [
                    {
                        "id": site["id"],
                        "name": site["displayName"],
                        "webUrl": site["webUrl"],
                    }
                    for site in sites
                ]
            return []

    async def _list_drives(self, params: Dict[str, Any]) -> List[Dict]:
        """List document libraries (drives)"""
        site_id = params.get("site_id")
        url = f"{self.graph_endpoint}/sites/{site_id}/drives"

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers={"Authorization": f"Bearer {self.access_token}"}
            )

            if response.status_code == 200:
                drives = response.json().get("value", [])
                return [
                    {
                        "id": drive["id"],
                        "name": drive["name"],
                        "driveType": drive["driveType"],
                    }
                    for drive in drives
                ]
            return []

"""
GitHub connector for repository and code operations
"""

from typing import Any, Dict, List
import os
from github import Github, GithubException
import logging

from .base import BaseConnector

logger = logging.getLogger(__name__)

class GitHubConnector(BaseConnector):
    """Connector for GitHub API"""

    def __init__(self):
        super().__init__()
        self.client = None
        self.token = os.getenv("GITHUB_TOKEN")

    async def connect(self) -> bool:
        """Connect to GitHub"""
        try:
            if not self.token:
                logger.warning("No GitHub token provided, using unauthenticated access")
            self.client = Github(self.token)
            self.connected = True
            return True
        except Exception as e:
            logger.error(f"Failed to connect to GitHub: {str(e)}")
            return False

    async def disconnect(self) -> bool:
        """Disconnect from GitHub"""
        if self.client:
            self.client.close()
        self.connected = False
        return True

    async def execute(self, operation: str, parameters: Dict[str, Any]) -> Any:
        """Execute GitHub operation"""
        if not self.connected:
            await self.connect()

        operations = {
            "search_code": self._search_code,
            "search_repositories": self._search_repositories,
            "get_repository": self._get_repository,
            "get_file": self._get_file,
            "list_branches": self._list_branches,
            "create_issue": self._create_issue,
            "create_pr": self._create_pr,
        }

        if operation not in operations:
            raise ValueError(f"Unknown operation: {operation}")

        return await operations[operation](parameters)

    async def health_check(self) -> bool:
        """Check GitHub API health"""
        try:
            if not self.client:
                return False
            self.client.get_user().login
            return True
        except:
            return False

    async def _search_code(self, params: Dict[str, Any]) -> List[Dict]:
        """Search code across repositories"""
        query = params.get("query")
        repo = params.get("repo")

        if repo:
            query = f"{query} repo:{repo}"

        try:
            results = self.client.search_code(query)
            return [
                {
                    "path": item.path,
                    "repo": item.repository.full_name,
                    "url": item.html_url,
                    "score": item.score,
                }
                for item in results[:20]  # Limit to 20 results
            ]
        except GithubException as e:
            logger.error(f"GitHub search error: {str(e)}")
            return []

    async def _search_repositories(self, params: Dict[str, Any]) -> List[Dict]:
        """Search repositories"""
        query = params.get("query")

        try:
            results = self.client.search_repositories(query)
            return [
                {
                    "name": repo.full_name,
                    "description": repo.description,
                    "url": repo.html_url,
                    "stars": repo.stargazers_count,
                    "language": repo.language,
                }
                for repo in results[:10]
            ]
        except GithubException as e:
            logger.error(f"GitHub repo search error: {str(e)}")
            return []

    async def _get_repository(self, params: Dict[str, Any]) -> Dict:
        """Get repository details"""
        repo_name = params.get("repo")
        repo = self.client.get_repo(repo_name)

        return {
            "name": repo.full_name,
            "description": repo.description,
            "url": repo.html_url,
            "default_branch": repo.default_branch,
            "stars": repo.stargazers_count,
            "forks": repo.forks_count,
        }

    async def _get_file(self, params: Dict[str, Any]) -> Dict:
        """Get file content from repository"""
        repo_name = params.get("repo")
        path = params.get("path")
        ref = params.get("ref", "main")

        repo = self.client.get_repo(repo_name)
        content = repo.get_contents(path, ref=ref)

        return {
            "path": content.path,
            "content": content.decoded_content.decode("utf-8"),
            "sha": content.sha,
            "size": content.size,
        }

    async def _list_branches(self, params: Dict[str, Any]) -> List[str]:
        """List repository branches"""
        repo_name = params.get("repo")
        repo = self.client.get_repo(repo_name)
        return [branch.name for branch in repo.get_branches()]

    async def _create_issue(self, params: Dict[str, Any]) -> Dict:
        """Create GitHub issue"""
        repo_name = params.get("repo")
        title = params.get("title")
        body = params.get("body")

        repo = self.client.get_repo(repo_name)
        issue = repo.create_issue(title=title, body=body)

        return {
            "number": issue.number,
            "url": issue.html_url,
            "state": issue.state,
        }

    async def _create_pr(self, params: Dict[str, Any]) -> Dict:
        """Create pull request"""
        repo_name = params.get("repo")
        title = params.get("title")
        body = params.get("body")
        head = params.get("head")
        base = params.get("base", "main")

        repo = self.client.get_repo(repo_name)
        pr = repo.create_pull(title=title, body=body, head=head, base=base)

        return {
            "number": pr.number,
            "url": pr.html_url,
            "state": pr.state,
        }

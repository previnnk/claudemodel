"""
Integration Layer Service
Provides pluggable connectors for enterprise systems
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import logging
from enum import Enum

from connectors.base import BaseConnector
from connectors.github_connector import GitHubConnector
from connectors.sharepoint_connector import SharePointConnector
from connectors.confluence_connector import ConfluenceConnector
from connectors.database_connector import OracleConnector, SQLServerConnector
from connectors.fhir_connector import FHIRConnector

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Integration Layer Service",
    description="Pluggable connectors for enterprise systems",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ConnectorType(str, Enum):
    GITHUB = "github"
    SHAREPOINT = "sharepoint"
    CONFLUENCE = "confluence"
    ORACLE = "oracle"
    SQLSERVER = "sqlserver"
    EPIC_FHIR = "epic_fhir"
    JIRA = "jira"

class ConnectorFactory:
    """Factory for creating connector instances"""

    _connectors: Dict[str, BaseConnector] = {}

    @classmethod
    def get_connector(cls, connector_type: ConnectorType) -> BaseConnector:
        """Get or create a connector instance"""
        if connector_type.value not in cls._connectors:
            cls._connectors[connector_type.value] = cls._create_connector(connector_type)
        return cls._connectors[connector_type.value]

    @classmethod
    def _create_connector(cls, connector_type: ConnectorType) -> BaseConnector:
        """Create a new connector instance"""
        if connector_type == ConnectorType.GITHUB:
            return GitHubConnector()
        elif connector_type == ConnectorType.SHAREPOINT:
            return SharePointConnector()
        elif connector_type == ConnectorType.CONFLUENCE:
            return ConfluenceConnector()
        elif connector_type == ConnectorType.ORACLE:
            return OracleConnector()
        elif connector_type == ConnectorType.SQLSERVER:
            return SQLServerConnector()
        elif connector_type == ConnectorType.EPIC_FHIR:
            return FHIRConnector()
        else:
            raise ValueError(f"Unknown connector type: {connector_type}")

class QueryRequest(BaseModel):
    connector: ConnectorType
    operation: str  # search, get, list, query, etc.
    parameters: Dict[str, Any]

class QueryResponse(BaseModel):
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

@app.get("/")
async def root():
    return {
        "service": "Integration Layer",
        "version": "1.0.0",
        "available_connectors": [ct.value for ct in ConnectorType]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}

@app.get("/connectors")
async def list_connectors():
    """List available connectors"""
    return {
        "connectors": [
            {
                "type": ct.value,
                "description": f"{ct.value.title()} integration",
                "operations": ["search", "get", "list"]
            }
            for ct in ConnectorType
        ]
    }

@app.post("/query", response_model=QueryResponse)
async def query(request: QueryRequest):
    """
    Execute a query against an external system
    """
    try:
        logger.info(f"Query: {request.connector} - {request.operation}")

        connector = ConnectorFactory.get_connector(request.connector)

        # Execute operation
        result = await connector.execute(request.operation, request.parameters)

        return QueryResponse(
            success=True,
            data=result,
            metadata={"connector": request.connector.value}
        )

    except Exception as e:
        logger.error(f"Query error: {str(e)}")
        return QueryResponse(
            success=False,
            error=str(e)
        )

@app.post("/github/search")
async def github_search(query: str, repo: Optional[str] = None):
    """Search GitHub repositories and code"""
    try:
        connector = ConnectorFactory.get_connector(ConnectorType.GITHUB)
        results = await connector.execute("search_code", {"query": query, "repo": repo})
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/sharepoint/search")
async def sharepoint_search(query: str, site: Optional[str] = None):
    """Search SharePoint documents"""
    try:
        connector = ConnectorFactory.get_connector(ConnectorType.SHAREPOINT)
        results = await connector.execute("search_documents", {"query": query, "site": site})
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/confluence/search")
async def confluence_search(query: str, space: Optional[str] = None):
    """Search Confluence pages"""
    try:
        connector = ConnectorFactory.get_connector(ConnectorType.CONFLUENCE)
        results = await connector.execute("search_pages", {"query": query, "space": space})
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/database/query")
async def database_query(
    connector_type: ConnectorType,
    query: str,
    params: Optional[Dict[str, Any]] = None
):
    """Execute database query (read-only)"""
    try:
        if connector_type not in [ConnectorType.ORACLE, ConnectorType.SQLSERVER]:
            raise ValueError("Invalid database connector type")

        connector = ConnectorFactory.get_connector(connector_type)
        results = await connector.execute("query", {"sql": query, "params": params})
        return {"success": True, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/fhir/patient")
async def fhir_get_patient(patient_id: str):
    """Retrieve patient data from FHIR"""
    try:
        connector = ConnectorFactory.get_connector(ConnectorType.EPIC_FHIR)
        results = await connector.execute("get_patient", {"patient_id": patient_id})
        return {"success": True, "data": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003)

"""
Embedding Service - Generate embeddings for text/code
Uses SentenceTransformers for fast embedding generation
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import logging
import os

from sentence_transformers import SentenceTransformer
import torch

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
MODEL_NAME = os.getenv("MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2")
DEVICE = os.getenv("DEVICE", "cpu")  # 'cuda' for GPU

app = FastAPI(title="Embedding Service", version="0.1.0")

# Global model instance
model = None

@app.on_event("startup")
async def load_model():
    """Load the embedding model on startup"""
    global model
    logger.info(f"Loading embedding model: {MODEL_NAME}")
    logger.info(f"Using device: {DEVICE}")

    try:
        model = SentenceTransformer(MODEL_NAME, device=DEVICE)
        logger.info("Model loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load model: {str(e)}")
        raise

class EmbeddingRequest(BaseModel):
    texts: List[str]
    normalize: bool = True

class EmbeddingResponse(BaseModel):
    embeddings: List[List[float]]
    model: str
    dimension: int

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model": MODEL_NAME,
        "device": DEVICE,
        "model_loaded": model is not None
    }

@app.post("/embed", response_model=EmbeddingResponse)
async def generate_embeddings(request: EmbeddingRequest):
    """Generate embeddings for input texts"""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    try:
        logger.info(f"Generating embeddings for {len(request.texts)} texts")

        # Generate embeddings
        embeddings = model.encode(
            request.texts,
            normalize_embeddings=request.normalize,
            show_progress_bar=False
        )

        # Convert to list
        embeddings_list = embeddings.tolist()

        return EmbeddingResponse(
            embeddings=embeddings_list,
            model=MODEL_NAME,
            dimension=len(embeddings_list[0]) if embeddings_list else 0
        )

    except Exception as e:
        logger.error(f"Error generating embeddings: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/model/info")
async def model_info():
    """Get information about the loaded model"""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    return {
        "model_name": MODEL_NAME,
        "max_seq_length": model.max_seq_length,
        "embedding_dimension": model.get_sentence_embedding_dimension(),
        "device": str(model.device)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)

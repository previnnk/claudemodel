import './App.css'

function App() {
  return (
    <div className="app">
      <header className="app-header">
        <h1>AI Coding Assistant</h1>
        <p>Powered by Open Source LLMs</p>
      </header>

      <main className="app-main">
        <div className="chat-container">
          <div className="chat-messages">
            <div className="message assistant">
              <p>Hello! I'm your AI coding assistant. How can I help you today?</p>
            </div>
          </div>

          <div className="chat-input-container">
            <textarea
              className="chat-input"
              placeholder="Ask me anything about your code..."
              rows={3}
            />
            <button className="send-button">Send</button>
          </div>
        </div>

        <div className="sidebar">
          <h3>Available Tools</h3>
          <ul>
            <li>📖 Read - Read files</li>
            <li>✏️ Write - Write files</li>
            <li>🔧 Edit - Edit files</li>
            <li>💻 Bash - Run commands</li>
            <li>🔍 Grep - Search code</li>
            <li>📁 Glob - Find files</li>
          </ul>
        </div>
      </main>
    </div>
  )
}

export default App
